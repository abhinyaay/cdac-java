package com.abhinyaay.linkedlist;

public class Node
{
    Object data;
    Node next;

    public Node()
    {
        data = null;
        next = null;
    }

    public Node(Object data)
    {
        this.data = data;
        this.next = null;
    }

    public Object getData()
    {
        return data;
    }

    public void setData(Object data)
    {
        this.data = data;
    }

    public Node getNext()
    {
        return next;
    }

    public void setNext(Node next)
    {
        this.next = next;
    }
}
