package calculator;

class Program {

    // ===== ADD =====
    int add(int a, int b) {
        return a + b;
    }

    float add(float a, float b) {
        return a + b;
    }

    float add(int a, float b) {
        return a + b;
    }

    float add(float a, int b) {
        return a + b;
    }

    // ===== SUBTRACT =====
    int subtract(int a, int b) {
        return a - b;
    }

    float subtract(float a, float b) {
        return a - b;
    }

    float subtract(int a, float b) {
        return a - b;
    }

    float subtract(float a, int b) {
        return a - b;
    }

    // ===== MULTIPLY =====
    int multiply(int a, int b) {
        return a * b;
    }

    float multiply(float a, float b) {
        return a * b;
    }

    float multiply(int a, float b) {
        return a * b;
    }

    float multiply(float a, int b) {
        return a * b;
    }

    // ===== DIVIDE =====
    int divide(int a, int b) {
        return a / b;
    }

    float divide(float a, float b) {
        return a / b;
    }

    float divide(int a, float b) {
        return a / b;
    }

    float divide(float a, int b) {
        return a / b;
    }
}