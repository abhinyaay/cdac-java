package Date;

import com.Day2.ConsoleInput;

public class Date {

	private int day;
	private int month;
	private int year;
	
	public Date() {
		this.day = 0;
		this.month = 0;
		this.year = 0;
	}
	
	// check Leap Year
	private boolean isLeapYear(int year) {
		return ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0));
	}
	
	// validate Day
	private int validateDay(int month, int year, int day) {
		if (month == 2) {
	        if (isLeapYear(year)) {
	            if (day > 29 || day < 1) {
	                day = 1;
	            }
	        } else {
	            if (day > 28 || day < 1) {
	                day = 1;
	            }
	        }
	    }
		
		else if((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && (day > 31 || day < 1)) {
			day = 1;
		}
		else if((month == 4 || month == 6 || month == 9 || month == 11) && (day > 30 || day < 1)) {
			day = 1;
		}
		else {
			return day;
		}
		
		return day;
	}
	
	// set Date to Object
	public void setDate() {
		
		System.out.println("Enter Day");
		int day = ConsoleInput.getInt();
		System.out.println("Enter Month");
		int month = ConsoleInput.getInt();
		System.out.println("Enter Year");
		int year = ConsoleInput.getInt();
		
		if(month > 12 || month < 1) {
			month = 1;
		}
		
		if(year < 1700 || year > 3100 ) {
			year = 2026;
		}
		
		day = validateDay(month, year, day);
		
		this.day = day;
		this.month = month;
		this.year = year;	

	}
	
	// show Date
	public void showDate() {
		System.out.println(day + "/" + month + "/" + year );
	}
	
	// set Days in Month
    private int setDaysInMonth(int daysInMonth) {
    	if (month == 2) {
            if (isLeapYear(year)) {
                daysInMonth = 29;
            } else {
                daysInMonth = 28;
            }
        } else if (month == 1 || month == 3 || month == 5 || month == 7 ||
                   month == 8 || month == 10 || month == 12) {
            daysInMonth = 31;
        } else {
            daysInMonth = 30;
        }
    	return daysInMonth;
    }
    
    // add Days to Object Date
	public void addDays(int addDays) {
	    this.day += addDays;
	    
	    while (true) {
	        int daysInMonth=0;

	        daysInMonth = setDaysInMonth(daysInMonth);
	        
	        if (day > daysInMonth) {
	            day -= daysInMonth;
	            month++;
	            if (month > 12) {
	                month = 1;
	                year++;
	            }
	        } else if (day < 1) {
	            month--;
	            if (month < 1) {
	                month = 12;
	                year--;
	            }
	   
	            daysInMonth = setDaysInMonth(daysInMonth);
		        
	            day += daysInMonth;
	        } else {
	            break;
	        }
	    }
	}

    // add Months to Object Date
	public void addMonths(int addMonths) {
	    this.month += addMonths;

	    while (month > 12) {
	        month -= 12;
	        year++;
	    }
	    while (month < 1) {
	        month += 12;
	        year--;
	    }

	    int daysInMonth = 0;
	    
	    daysInMonth = setDaysInMonth(daysInMonth);

	    if (day > daysInMonth) {
	        day = daysInMonth;
	    }
	}
	
    // add Years to Object Date
	public void addYears(int addYears) {
	    this.year += addYears;

	    if (month == 2) {
	        if (isLeapYear(year)) {
	            if (day > 29 || day < 1) {
	                day = 29;
	            }
	        } else {
	            if (day > 28 || day < 1) {
	                day = 28;
	            }
	        }
	    }
	}
	
	// compare Entered Date with Object Date
	public boolean compareDates() {
		System.out.println("Enter Day");
		int day = ConsoleInput.getInt();
		System.out.println("Enter Month");
		int month = ConsoleInput.getInt();
		System.out.println("Enter Year");
		int year = ConsoleInput.getInt();
		
		if(month > 12 || month < 1) {
			month = 1;
		}
		
		if(year < 1700 || year > 3100) {
			year = 2026;
		}
		
		day = validateDay(month, year, day);

		System.out.print("Comparing entered date: " + day + "/" + month + "/" + year );
		System.out.println(" with Object date: " + this.day + "/" + this.month + "/" + this.year );
		
		//calculate total days
		
		int total_original_days = dateToDays(this.day, this.month, this.year);
		int total_entered_days = dateToDays(day, month, year);
		
		//Difference in absolute days
		int diff_abs_date = total_entered_days - total_original_days ;
		
		System.out.println("Days in Entered Date: " + total_entered_days + " Days in Original Date: " + total_original_days);		
		System.out.println("Difference Between two dates is: " + diff_abs_date);

		boolean cmp = ( this.day == day && this.month == month && this.year == year);
		return cmp;
	}
	
	// convert days, months, years into total days 
	public int dateToDays(int days, int months, int years) {
		
		int total_days = 0;
		
		//day to days
		total_days += days;
		
		//years to days
		int leap_y = (int)years/4;
		int non_leap_y = years - leap_y ;
		
		total_days += leap_y * 366;
		total_days += non_leap_y * 365;
		
		//months to days
		for(int i = 1 ; i<= months; i++) {
		
		if (months == 2) {
	        if (isLeapYear(years)) {
	        	total_days += 29;
	            
	        } else {
	        	total_days += 28;
	        }
	    }
		else if(months == 1 || months == 3 || months == 5 || months == 7 || months == 8 || months == 10 || months == 12) {
			total_days += 31;
		}
		else if(months == 4 || months == 6 || months == 9 || months == 11) {
			total_days += 30;
		}
		}
		
		return total_days;
		
	}
}
