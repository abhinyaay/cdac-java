package Date;

import com.Day2.ConsoleInput;

class DateMenu {
	
    public static void main(String[] args) {
        String choice;

        Date date = new Date();

        do {

            System.out.println("== Date Menu ===");

            System.out.println("1. Set Date");
            System.out.println("2. Get Date");
            System.out.println("3. Add Days");
            System.out.println("4. Add Months");
            System.out.println("5. Add Years");
            System.out.println("6. Compare Date");
            System.out.println("7. Exit");

            System.out.println("Select Option");
            int option = ConsoleInput.getInt();

            switch (option) {

                case 1: {
                    date.setDate();
                    date.showDate();
                }
                break;
                case 2:
                    date.showDate();
                    break;
                case 3: {
                    System.out.println("Enter Day");
                    int day = ConsoleInput.getInt();
                    date.addDays(day);
                    date.showDate();
                }
                break;
                case 4: {
                    System.out.println("Enter Month");
                    int month = ConsoleInput.getInt();
                    date.addMonths(month);
                    date.showDate();
                }
                break;
                case 5: {
                    System.out.println("Enter Year");
                    int year = ConsoleInput.getInt();
                    date.addYears(year);
                    date.showDate();
                }
                break;
                case 6:
                    if(date.compareDates()) {
                    	System.out.println("Dates are Equal!");
                    } else {
                    	System.out.println("Dates are Unqual!");
                    }
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Option Invalid !");
                    break;

            }

            System.out.println("Press Y to continue !");
            choice = ConsoleInput.getString();

        } while (choice.trim().equalsIgnoreCase("Y"));
    }
}
