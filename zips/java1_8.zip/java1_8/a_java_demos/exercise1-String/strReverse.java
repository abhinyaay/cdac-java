import java.util.* ;

public class strReverse {

public static void main(String [] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("The given string is: ");
        String str = sc.nextLine();
        String str_rev = "";
        int n = str.length();
        for(int i = n-1 ; i >= 0 ; i--) {
            str_rev = str_rev + str.charAt(i);
        }
        System.out.println("The string in reverse order is: " + str_rev);
        }
}