import java.util.* ;

public class getIndex {

public static void main(String [] args) {
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a Sentence: ");
	String str = sc.nextLine();
        System.out.println(str);
	System.out.println("The character at position 0 is " + str.charAt(0));
	System.out.println("The character at position 10 is " + str.charAt(10));

        }
}
