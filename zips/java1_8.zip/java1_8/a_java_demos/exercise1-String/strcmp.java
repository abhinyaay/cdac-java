import java.util.* ;

public class strcmp {

public static void main(String [] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("String 1: ");
        String str1 = sc.nextLine();
        System.out.print("String 2: ");
        String str2 = sc.nextLine();
        int cmp = str1.compareTo(str2);
        if(cmp < 0) {
        System.out.println( str1 + " is less than " + str2 );
        } else if(cmp > 0) { 
        System.out.println( str1 + " is less than " + str2 );
        } else {
        System.out.println( str1 + " is equal to " + str2 );
        }
        }
}