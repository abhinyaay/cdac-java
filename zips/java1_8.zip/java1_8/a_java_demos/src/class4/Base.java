package class4;

public class Base {
	protected int data;

	public void show() {
	System.out.println("Show Base of base");
	}
	
	public void display() {
	System.out.println("Display of base");
	}
}
