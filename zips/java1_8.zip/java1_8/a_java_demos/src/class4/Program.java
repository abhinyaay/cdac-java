package class4;

public class Program {

public static void main(String[] args) {

Base objBase = new Derived();

objBase.display();

}
}