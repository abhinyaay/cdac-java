package class4;

public class Data {
int value;
int data;
int flag;

final int MAX = 22 ;

public Data() {
	System.out.println("Default Initialization");
}

public Data(int num) {
	this(num,2);
}

public Data(int num1, int num2) {
	System.out.println("init for num and num2");
	value = num1;
	data = num2;
	flag = 3;

}

public void increment()
{ 
	
	value = value + 10;
	this.value = this.value + 10;
}

public void setValue(int value) {
	this.value = value;
}

}
