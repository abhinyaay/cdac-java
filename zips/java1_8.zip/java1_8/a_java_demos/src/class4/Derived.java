package class4;

public class Derived extends Base {

	int value;

@Override
public void display() {
System.out.println("Display of derived");
}

}
