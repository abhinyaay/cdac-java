import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ComplexNumber[] complexNumbers = new ComplexNumber[5];

        for (int i = 0; i < 5; i++) {
            complexNumbers[i] = new ComplexNumber();
        }

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter number1 for ComplexNumber " + (i + 1) + ": ");
            int num1 = scanner.nextInt();
            complexNumbers[i].setNumber1(num1);

            System.out.print("Enter number2 for ComplexNumber " + (i + 1) + ": ");
            int num2 = scanner.nextInt();
            complexNumbers[i].setNumber2(num2);
        }

        // Loop to compute and display results
        System.out.println("\nResults:");
        for (int i = 0; i < 5; i++) {
            int result = complexNumbers[i].computeComplexNumber();
            System.out.println("ComplexNumber " + (i + 1) + " product: " + result);
        }

        scanner.close();
    }
}
