import java.util.* ;

public class NumPattern {

public static void main(String [] args) {
        int sum = 1;

// 1
// 2 3
// 4 5 6
// 7 8 9 10
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < i+1; j++) {
                System.out.print(sum + " ");
                sum++;
            }    
            System.out.println();
        }

System.out.println();
System.out.println();
System.out.println();

// 1
// 1 2 
// 1 2 3
// 1 2 3 4
// 1 2 3 4 5
// 1 2 3 4 5 6
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < i+1; j++) {
                System.out.print(j + 1 + " ");
            }    
            System.out.println();
        }

System.out.println();
System.out.println();
System.out.println();

// 1 2 3 4 5 6
// 1 2 3 4 5
// 1 2 3 4
// 1 2 3
// 1 2 
// 1
        for (int i = 6; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print(j + 1 + " ");
            }    
            System.out.println();
        }

        }
}