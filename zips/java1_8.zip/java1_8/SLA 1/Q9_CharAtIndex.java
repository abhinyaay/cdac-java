public class Q9_CharAtIndex {
    public static void main(String[] args) {
        String s = "Java Exercises!";
        System.out.println("Original String = " + s);
        System.out.println("The character at position 0 is " + s.charAt(0));
        System.out.println("The character at position 10 is " + s.charAt(10));
    }
}
