public class Q11_StringEndsWith {
    public static void main(String[] args) {
        String s1 = "Python Exercises";
        String s2 = "Python Exercise";
        String end = "se";
        System.out.println("\"" + s1 + "\" ends with \"" + end + "\"? " + s1.endsWith(end));
        System.out.println("\"" + s2 + "\" ends with \"" + end + "\"? " + s2.endsWith(end));
    }
}
