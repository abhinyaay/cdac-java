public class Q1_Odd {
    public static void main(String[] args) {
        System.out.println("Odd numbers from 1 to 1000:");
        for (int i = 1; i <= 1000; i += 2) {
            System.out.println(i);
        }
    }
}
