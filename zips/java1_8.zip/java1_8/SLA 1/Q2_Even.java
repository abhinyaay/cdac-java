public class Q2_Even {
    public static void main(String[] args) {
        System.out.println("Even numbers from 1 to 500:");
        for (int i = 2; i <= 500; i += 2) {
            System.out.println(i);
        }
    }
}
