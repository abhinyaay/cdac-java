public class Q3_7thNum {
    public static void main(String[] args) {
        System.out.println("Every 7th number from 1 to 200:");
        for (int i = 7; i <= 200; i += 7) {
            System.out.println(i);
        }
    }
}
