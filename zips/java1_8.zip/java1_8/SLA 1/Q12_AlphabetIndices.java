public class Q12_AlphabetIndices {
    public static void main(String[] args) {
        String s = "The quick brown fox jumps over the lazy dog.";
        System.out.println("a b c d e f g h i j");
        System.out.println("=========================");
        System.out.print(s.lastIndexOf('a') + " ");
        System.out.print(s.lastIndexOf('b') + " ");
        System.out.print(s.lastIndexOf('c') + " ");
        System.out.print(s.lastIndexOf('d') + " ");
        System.out.print(s.lastIndexOf('e') + " ");
        System.out.print(s.lastIndexOf('f') + " ");
        System.out.print(s.lastIndexOf('g') + " ");
        System.out.print(s.lastIndexOf('h') + " ");
        System.out.print(s.lastIndexOf('i') + " ");
        System.out.println(s.lastIndexOf('j'));
        System.out.println("k l m n o p q r s t");
        System.out.println("===========================");
        System.out.print(s.lastIndexOf('k') + " ");
        System.out.print(s.lastIndexOf('l') + " ");
        System.out.print(s.lastIndexOf('m') + " ");
        System.out.print(s.lastIndexOf('n') + " ");
        System.out.print(s.lastIndexOf('o') + " ");
        System.out.print(s.lastIndexOf('p') + " ");
        System.out.print(s.lastIndexOf('q') + " ");
        System.out.print(s.lastIndexOf('r') + " ");
        System.out.print(s.lastIndexOf('s') + " ");
        System.out.println(s.lastIndexOf('t'));
        System.out.println("u v w x y z");
        System.out.println("================ ");
        System.out.print(s.lastIndexOf('u') + " ");
        System.out.print(s.lastIndexOf('v') + " ");
        System.out.print(s.lastIndexOf('w') + " ");
        System.out.print(s.lastIndexOf('x') + " ");
        System.out.print(s.lastIndexOf('y') + " ");
        System.out.println(s.lastIndexOf('z'));
        System.out.println("Sample string of all alphabet: \"" + s + "\"");
    }
}
