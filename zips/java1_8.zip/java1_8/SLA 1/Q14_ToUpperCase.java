public class Q14_ToUpperCase {
    public static void main(String[] args) {
        String s = "The Quick BroWn FoX!";
        System.out.println("Original String: " + s);
        System.out.println("String in uppercase: " + s.toUpperCase());
    }
}
