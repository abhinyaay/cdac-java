public class Q15_ReverseString {
    public static void main(String[] args) {
        String s = "The quick brown fox jumps";
        System.out.println("The given string is: " + s);
        System.out.println("The string in reverse order is:");
        for (int i = s.length() - 1; i >= 0; i--) {
            System.out.print(s.charAt(i));
        }
    }
}
