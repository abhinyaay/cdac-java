public class Q13_ReplaceSubstring {
    public static void main(String[] args) {
        String s = "The quick brown fox jumps over the lazy dog.";
        System.out.println("Original string: " + s);
        String newStr = s.replace("fox", "cat");
        System.out.println("New String: " + newStr);
    }
}
