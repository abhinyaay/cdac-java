package com.abhinyaay.utils;

public class Node<T> {

	T data;
	Node<T> next;
	Node<T> previous;
	public Node(T temp) {
		data = temp;
	}
}
