package com.abhinyaay.utils;

public class LinkedList<T> {

	Node<T> start;
	Node<T> end;
	Node<T> current;
	int maxCount;
	
	public void add(T data) {
		
		Node<T> node = new Node<T>(data);
		
		if(start == null)
			start = end = current = node ;
		else {
			end.next = node ;
			node.previous = end ;
			end = node ;
		}
		maxCount++;
		System.out.println("Node Added");
	}
	
	public void delete(int index) {
		if(start == null || index > maxCount-1) {
			System.out.println("Node to be deleted not found");
			return;
		}
		
		if(start == end)
			start = end = current = null ;
		
		else if(index == 0) {
			start = start.next;
			start.next.previous = null;
		} 
		
		else if (index == maxCount-1) {
			end = end.previous;
			end.next = null;
		}
		
		else {
			
			Node<T> node = start ;
			
			for(int iTemp = 0; iTemp < index; iTemp++ , node = node.next);
			
			node.next.previous = node.previous;
			node.previous.next = node.next;
			node = null;
				
		}
		maxCount--;
		System.out.println("Node Deleted");
	}
	
	public T getFirst() {
		if(start == null) {
			System.out.println("Node not found");
			return null;
		}
		current = start;
		return current.data;
	}
	
	public T getLast() {
		if(start == null) {
			System.out.println("Node not found");
			return null;
		}
		
		current = end;
		return current.data;
	}
	
	public T getNext() {
		if(start == null || current == end) {
			System.out.println("Node not found");
			return null;
		}
		
		current = current.next;
		return current.data;
	}
	
	public T getPrevious() {
		if(start == null || current == start) {
			System.out.println("Node not found");
			return null;
		}
		
		current = current.previous;
		return current.data;
	}
	
	public int getMaxCount() {
		return maxCount;
	}
}
