package Day_2;

public class Calculator {
    public static void main(String []args) {
        String ch;
        do {

            System.out.println("== Options ===");
            
            System.out.println("1. Add 2 Integers");
            System.out.println("2. Add 2 Floats");
            System.out.println("3. Add an Int and Float");
            System.out.println("4. Subtract 2 Integers");
            System.out.println("5. Subtract 2 Floats");
            System.out.println("6. Subtract an Int and Float");
            System.out.println("7. Multiply 2 Integers");
            System.out.println("8. Multiply Floats");
            System.out.println("9. Multiply Integer and Float");
            System.out.println("10. Exit");

            System.out.println("Select Option");
            int option = ConsoleInput.getInt();
            
            switch(option) {
            
            case 1: {
                System.out.println("Enter 1st Integer");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Integer");
                int num2 = ConsoleInput.getInt();
                Calculate objCalculate = new Calculate();
                System.out.println("Sum of Integers is: " + objCalculate.add(num1, num2));
            }
                break;
            case 2: {
                System.out.println("Enter 1st Float Number");
                float num1 = ConsoleInput.getFloat();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Sum of Float Numbers is: " + objCalculate.add(num1, num2));
            }
                break;
            case 3: {
                System.out.println("Enter 1st Integer Number");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Sum of Integer and Float is: " + objCalculate.add(num1, num2));
            }
                break;
            case 4: {
                System.out.println("Enter 1st Integer");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Integer");
                int num2 = ConsoleInput.getInt();
                Calculate objCalculate = new Calculate();
                System.out.println("Difference of Integers is: " + objCalculate.subtract(num1, num2));
            }
                break;
            case 5: {
                System.out.println("Enter 1st Float Number");
                float num1 = ConsoleInput.getFloat();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Difference of Float Numbers is: " + objCalculate.subtract(num1, num2));
            }
                break;
            case 6: {
                System.out.println("Enter 1st Integer Number");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Difference of Integer and Float is: " + objCalculate.subtract(num1, num2));
            }
                break;
            case 7: {
                System.out.println("Enter 1st Integer");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Integer");
                int num2 = ConsoleInput.getInt();
                Calculate objCalculate = new Calculate();
                System.out.println("Product of Integers is: " + objCalculate.multiply(num1, num2));
            }
                break;
            case 8: {
                System.out.println("Enter 1st Float Number");
                float num1 = ConsoleInput.getFloat();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Product of Float Numbers is: " + objCalculate.multiply(num1, num2));
            }
                break;
            case 9: {
                System.out.println("Enter 1st Integer Number");
                int num1 = ConsoleInput.getInt();
                System.out.println("Enter 2nd Float Number");
                float num2 = ConsoleInput.getFloat();
                Calculate objCalculate = new Calculate();
                System.out.println("Product of Integer and Float Numbers is: " + objCalculate.multiply(num1, num2));
            }
                break;
            case 10:
                    return;
            default: 
                System.out.println("Option Invalid !");
                break;
            
            }
            
            System.out.println("Press Y to continue !");
            ch = ConsoleInput.getString();
            
        } while( ch.trim().equalsIgnoreCase("Y"));
    }
}