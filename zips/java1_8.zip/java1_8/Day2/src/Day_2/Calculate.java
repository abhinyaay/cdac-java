package Day_2;

public class Calculate {
    
    public int add(int num1, int num2) {
        return num1 + num2;
    }

    public float add(float num1, float num2) {
        return num1 + num2;
    }

    public float add(int num1, float num2) {
        return num1 + num2;
    }

    public int subtract(int num1, int num2) {
        return num1 - num2;
    }

    public float subtract(float num1, float num2) {
        return num1 - num2;
    }

    public float subtract(int num1, float num2) {
        return num1 - num2;
    }

    public float multiply(int num1, int num2) {
        return num1 * num2;
    }


    public float multiply(float num1, float num2) {
        return num1 * num2;
    }

    public float multiply(int num1, float num2) {
        return (float)num1 * num2;
    }

}