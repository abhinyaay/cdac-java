package org.huzaifa;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileInputStream;
import java.io.FileOutputStream;

import Day_2.ConsoleInput;

public class Program {

	public static void main(String[] args) {

		String choice;

		do {

			try {
				int option;

				final int WRITE_FILE = 1;
				final int ENCRYPT_FILE = 2;
				final int DECRYPT_FILE = 3;
				final int READ_FILE = 4;
				final int EXIT = 5;

				System.out.println("=== Select File Operation ===");
				System.out.println("1. WRITE_FILE");
				System.out.println("2. ENCRYPT_FILE");
				System.out.println("3. DECRYPT_FILE");
				System.out.println("4. READ_FILE");
				System.out.println("5. EXIT");

				option = ConsoleInput.getInt();
				switch (option) {
				case WRITE_FILE:
					writeToFile();
					break;
				case ENCRYPT_FILE: {
					encrypt_File();
				}
					break;
				case DECRYPT_FILE: {
					decrypt_File();
					readFromDecryptFile();
				}
					break;
				case READ_FILE:
					readFromFile();
					break;

				case EXIT: {
					System.out.println("Exiting from Program!!!");
					break;
				}
				default: {

				}
				}
			} catch (Exception e) {

				e.printStackTrace();
			}
			System.out.println("Press Y to continue to File Operations: ");
			choice = ConsoleInput.getString();

		} while (choice.trim().equalsIgnoreCase("Y"));

	}

	public static void decrypt_File() {

		try (FileInputStream encfile = new FileInputStream(
				"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.enc");
				FileOutputStream File = new FileOutputStream(
						"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.dec", true)) {

			File objFile = new File("C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.enc");
			int size = (int) objFile.length();
			byte data[] = new byte[size];
			encfile.read(data);
			
			File.write("Decrypted Data from Encrypted File:- \n".getBytes());
	        for(byte ch: data) {

				File.write((char)((int)ch - 10));
	        }
			System.out.println("Decrypted and Written Back to File Successfully!");


		} catch (Exception e) {
			System.out.println("Exception Caught: " + e.getMessage());
		}

	}
	
	public static void encrypt_File() {

		try (FileInputStream file = new FileInputStream(
				"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\file.txt");
				FileOutputStream encFile = new FileOutputStream(
						"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.enc", true)) {

			File objFile = new File("C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\file.txt");
			int size = (int) objFile.length();
			byte data[] = new byte[size];
			file.read(data);
	        for(byte ch: data) {

				encFile.write((char)((int)ch + 10));
	        }
			System.out.println("Encrypted and Written to File Successfully!");


		} catch (Exception e) {
			System.out.println("Exception Caught: " + e.getMessage());
		}

	}
	
	public static void readFromDecryptFile() {

		try (FileInputStream file = new FileInputStream(
				"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.dec")) {

			System.out.println("Reading from File");
			File objFile = new File("C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\File.dec");
			int size = (int) objFile.length();
			byte data[] = new byte[size];
			file.read(data);
			String str = new String(data);
			System.out.println(str);

		} catch (Exception e) {
			System.out.println("Exception Caught: " + e.getMessage());
		}

	}
	
	public static void readFromFile() {

		try (FileInputStream file = new FileInputStream(
				"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\file.txt")) {

			System.out.println("Reading from File");
			File objFile = new File("C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\file.txt");
			int size = (int) objFile.length();
			byte data[] = new byte[size];
			file.read(data);
			String str = new String(data);
			System.out.println(str);

		} catch (Exception e) {
			System.out.println("Exception Caught: " + e.getMessage());
		}

	}

	public static void writeToFile() {
		String write_choice;
		do {
			try (FileOutputStream file = new FileOutputStream(
					"C:\\Users\\pgcp-ac\\Documents\\Java\\a_java_demos\\FileHandling\\file.txt", true)) {

				System.out.println("Enter text to be written to file :-");
				String text = ConsoleInput.getString();
				file.write(text.getBytes());
				file.write("\n".getBytes());
				System.out.println("Written to File Successfully!");

			} catch (Exception e) {
				System.out.println("Exception Caught: " + e.getMessage());
			}
			System.out.println("Do you want to add more:- Y for Yes/ N for No ");
			write_choice = ConsoleInput.getString();
		} while (write_choice.trim().equalsIgnoreCase("Y"));
	}

}
