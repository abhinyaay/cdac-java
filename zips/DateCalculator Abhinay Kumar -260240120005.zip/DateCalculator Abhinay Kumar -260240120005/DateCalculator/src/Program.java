class Program {

    private int day, month, year;

    private int[] daysInMonth = {31,28,31,30,31,30,31,31,30,31,30,31};

    public boolean isLeapYear(int year) {
        return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
    }

    public int getDaysOfMonth(int month, int year) {
        if (month == 2 && isLeapYear(year)) {
            return 29;
        }
        return daysInMonth[month - 1];
    }

    public void setDate(int day, int month, int year) {

        if (year < 2000 || year > 2100) {
            year = 2026;
        }

        if (month < 1 || month > 12) {
            month = 1;
        }

        int maxDays = getDaysOfMonth(month, year);

        if (day < 1 || day > maxDays) {
            day = 1;
        }

        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int toTotalDays() {
        int total = 0;

        for (int i = 2000; i < year; i++) {
            total += isLeapYear(i) ? 366 : 365;
        }

        for (int i = 1; i < month; i++) {
            total += getDaysOfMonth(i, year);
        }

        total += day;

        return total;
    }

    public void fromTotalDays(int total) {

        year = 2000;

        while (true) {
            int daysInYear = isLeapYear(year) ? 366 : 365;

            if (total > daysInYear) {
                total -= daysInYear;
                year++;
            } else {
                break;
            }
        }

        month = 1;

        while (true) {
            int daysInMonth = getDaysOfMonth(month, year);

            if (total > daysInMonth) {
                total -= daysInMonth;
                month++;
            } else {
                break;
            }
        }

        day = total;
    }

    public void addDays(int numOfDays) {
        int total = toTotalDays();
        total += numOfDays;
        fromTotalDays(total);
    }

    public void addMonths(int numOfMonths) {
        month += numOfMonths;

        while (month > 12) {
            month -= 12;
            year++;
        }

        setDate(day, month, year);
    }

    public void addYears(int numOfYears) {
        year += numOfYears;
        setDate(day, month, year);
    }

    public void compare(int day, int month, int year) {

        int current = toTotalDays();

        Program temp = new Program();
        temp.setDate(day, month, year);

        int other = temp.toTotalDays();

        if (current == other)
            System.out.println("DATES ARE SAME !!!!");
        else
            System.out.println("DATES ARE NOT SAME !!!!!");
    }

    public void show() {
        System.out.println("Date: " + day + "/" + month + "/" + year);
    }
}