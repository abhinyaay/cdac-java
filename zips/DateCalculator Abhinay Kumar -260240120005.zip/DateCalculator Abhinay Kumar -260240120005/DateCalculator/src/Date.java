import java.util.Scanner;

class DateApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Program obj = new Program();

        int choice;

        do {
            System.out.println("\n1. Set Date");
            System.out.println("2. Add Days");
            System.out.println("3. Add Months");
            System.out.println("4. Add Years");
            System.out.println("5. Compare Date");
            System.out.println("6. Exit");

            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter day: ");
                    int d = sc.nextInt();

                    System.out.print("Enter month: ");
                    int m = sc.nextInt();

                    System.out.print("Enter year: ");
                    int y = sc.nextInt();

                    obj.setDate(d, m, y);
                    obj.show();
                    break;

                case 2:
                    System.out.println("Before:");
                    obj.show();

                    System.out.print("Enter days to add: ");
                    int days = sc.nextInt();

                    obj.addDays(days);

                    System.out.println("After:");
                    obj.show();
                    break;

                case 3:
                    System.out.print("Enter months to add: ");
                    int months = sc.nextInt();

                    obj.addMonths(months);
                    obj.show();
                    break;

                case 4:
                    System.out.print("Enter years to add: ");
                    int years = sc.nextInt();

                    obj.addYears(years);
                    obj.show();
                    break;

                case 5:
                    System.out.print("Enter day: ");
                    int cd = sc.nextInt();

                    System.out.print("Enter month: ");
                    int cm = sc.nextInt();

                    System.out.print("Enter year: ");
                    int cy = sc.nextInt();

                    obj.compare(cd, cm, cy);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while (choice != 6);

        sc.close();
    }
}